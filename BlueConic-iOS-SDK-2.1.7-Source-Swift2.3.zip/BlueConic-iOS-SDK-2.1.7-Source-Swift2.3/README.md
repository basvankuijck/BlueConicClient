## Usage

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

BlueConicClient is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod "BlueConicClient"
```

## Author

BlueConic, info@blueconic.com

## License

BlueConicClient is available under the commercial license. See the LICENSE file for more info.
