/*
 * $LastChangedBy$
 * $LastChangedDate$
 * $LastChangedRevision$
 * $HeadURL$
 *
 * Copyright 2014 BlueConic Inc./BlueConic B.V. All rights reserved.
 */

#import <UIKit/UIKit.h>
// Importing the Objective C BlueConicPlugin header.
#import "BlueConicPlugin.h"
//! Project version number for BlueConicClient.
FOUNDATION_EXPORT double BlueConicClientVersionNumber;

//! Project version string for BlueConicClient.
FOUNDATION_EXPORT const unsigned char BlueConicClientVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BlueConicClient/PublicHeader.h>





